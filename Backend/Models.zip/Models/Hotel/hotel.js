const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const HotelSchema = new Schema({
    hotelName: {
        type: String,
        required: true
    },
    description: {
        type: String,
    },
    email: {
        type: String,
    },
    mobileNumber: {
        type: String,
    },
    address: {
        type: String,
    },
    ////////////////////////////////Hotel code 
    hotel: {
        type:String
    },
    ////////////////////////////////////////////////////////////////////////
    countryId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "CountryState"
    }, 
    ////////////////////////////////////////////////////////////////////////
    starRating: {
        type: Number,
    },
    amenities: {
        type: [String],
    },
    image: {
        type: [String],
    },
    ////////////////////////////////////////////////////////////////////////
    managerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "employee",
        required: true
    },
    managerName: String,
    //////////////////////////
    status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
    },
    approvedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "superadmin"
    },
    approvedOn: Date,
    rejectReason: String,
    ////////////////////////////////////////////////////////////////////////
    customFields: [
        {
            fieldName: {
                type: String,
            },
            fieldValue: {
                type: mongoose.Schema.Types.Mixed,
            }
        }
    ],
    isActive: {
        type: Boolean,
        default: true
    },
    isDeleted: {
        type: Boolean,
        default: false
    }


});

const Hotel = mongoose.model('hotel', HotelSchema);

module.exports = Hotel;
