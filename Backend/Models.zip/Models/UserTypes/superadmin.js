const mongoose = require('mongoose');
const { token } = require('morgan');
const Schema = mongoose.Schema;
const passwordHash = require('password-hash');

const SuperAdminSchema = new Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    token : {
        type:String,
    },
    
 
}

);
SuperAdminSchema.methods.comparePassword= function(adminPassword){
return passwordHash.verify(adminPassword,this.password)}

const SuperAdmin = mongoose.model('superadmin', SuperAdminSchema);

module.exports = SuperAdmin;